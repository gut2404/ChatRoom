﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ChatRoom
{
    public class ChatData
    {
        public string content { get; set; }
        public DateTime time { get; set; }
        public string name { get; set; }
        public string sex { get; set; }
        public string info { get; set; }
    }
}
